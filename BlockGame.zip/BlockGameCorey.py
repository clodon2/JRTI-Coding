# Corey Verkouteren
# 2/11/22 -
# Testing out features

import pygame as pg
import pygame.freetype
from pygame.locals import *

# Block Jumper

# Notes: Collision system somewhat unorthodox, created myself, and thus went through many renditions which left
# the floor as it's own collision, if reused it will be fixed


class Player(pg.sprite.Sprite):
    jumpvelocity = -15
    gravity = 1
    airtime = 0
    collcount = 0
    xmovement = 0
    ymovement = 0
    jump = False
    collided = False

    def __init__(self, spriteimage):
        super(Player, self).__init__()
        self.surf = pg.image.load(spriteimage)
        self.rect = self.surf.get_rect(center=(
            (SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
        ))

    def setcollision(self, yn):
        self.collided = yn

    # obstacle collisions, inspired by Mr.Ball's version
    def collisioncheck(self, collrect):
        if pg.Rect.colliderect(self.rect, collrect):
            # bottom side collision
            if (self.rect.bottom - self.ymovement) <= collrect.top:
                player.rect.bottom = collrect.top
                self.jump = False
                self.ymovement = 0
                self.collcount = 0
            # right side collision
            elif self.rect.right >= collrect.left and self.rect.bottom > collrect.top and player.rect.right < collrect.right:
                player.rect.right = collrect.left
            # left side collision
            elif self.rect.left <= collrect.right and self.rect.bottom > collrect.top and player.rect.right > collrect.left:
                player.rect.left = collrect.right

    def update(self, keypress):
        self.ymovement = 0
        self.xmovement = 0
        # floor collision
        if self.collided:
            self.jump = False
            self.ymovement = 0
            self.collcount = 0
        elif not self.collided:
            if self.collcount < 1:
                # for gravity calculations, need time been in air
                self.airtime = pg.time.get_ticks()
            # adds gravity if player not on ground
            self.ymovement += self.gravity*((pg.time.get_ticks() - self.airtime)/60)
            self.collcount += 1

        # jump
        if keypress[K_w]:
            self.jump = True
        if self.jump:
            self.ymovement += self.jumpvelocity

        # horizontal movement
        if keypress[K_d]:
            self.xmovement += 3
        if keypress[K_a]:
            self.xmovement -= 3

        # final movement
        self.rect.move_ip(self.xmovement, self.ymovement)

        # keeps player on screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT


class Obstacle(pg.sprite.Sprite):
    def __init__(self, size, location):
        super(Obstacle, self).__init__()
        self.xmovement = 0
        self.surf = pg.surface.Surface(size)
        self.surf.fill(white)
        self.rect = self.surf.get_rect(center=location)

    def update(self):
        self.rect.move_ip(self.xmovement, 0)




SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
running = True

clock = pg.time.Clock()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("Block Jumper")
white = (255, 255, 255)
black = (0, 0, 0)
blue = (0, 0, 200)

player = Player("Images/blockcharacter.png")
floor = Obstacle((800, 100), (SCREEN_WIDTH / 2, 500))
block2 = Obstacle((50, 50), (400, 400))

obstacle_sprites = pg.sprite.Group()

obstacle_sprites.add(block2)

obstacle_rects = []

for i in obstacle_sprites:
    obstacle_rects.append(i.rect)

pg.init()
pg.font.init()

while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                running = False

    pressed_keys = pg.key.get_pressed()
    player.update(pressed_keys)

    for entity in obstacle_sprites:
        entity.movementpath()
        entity.update()

    # obstacle collision
    for i in obstacle_rects:
        player.collisioncheck(i)

    # floor collision
    if pg.Rect.colliderect(player.rect, floor):
        player.rect.bottom = floor.rect.top
        player.setcollision(True)
    else:
        player.setcollision(False)

    pg.draw.rect(screen, blue, screen.get_rect())
    screen.blit(floor.surf, floor.rect)
    screen.blit(block2.surf, block2.rect)
    screen.blit(player.surf, player.rect)
    pg.display.flip()
    clock.tick(30)
