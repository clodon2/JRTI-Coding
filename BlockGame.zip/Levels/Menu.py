import pygame as pg
import pygame.freetype
from pygame.locals import *
pygame.init()


class Button(pg.sprite.Sprite):
    def __init__(self, text, location):
        super(Button, self).__init__()
        self.surf = pg.surface.Surface((200, 100))
        self.surf.fill((50, 50, 255))
        self.rect = self.surf.get_rect(
            center=(
                    location,
                    ))

def MainMenu():
    inmenu = True
    Tutorial = Button("Tutorial", ())
    while inmenu:

