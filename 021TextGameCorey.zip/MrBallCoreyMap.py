#Robert  Ball
#Friday, March 04, 2022
#Directory of Directories

# Edited by Corey Verkouteren
# 3/4/2022 - 3/7/2022
# Mr.Ball's PM
# Map for text-based escape game

import winsound
import time
from sys import stdout
import random

def loadMap():
    # These are the long descriptions  that tells the user where they are and what choices they have
    R1ld = "Weeeellllcooooommmmeeee tooooo EFFFOORRTTLESSSS ESSSCAAPPPPEEEE!!\nI'm your host Joe Florenzo and today " \
        "we have a very exciting episode!\n" \
        "Our contestants must make it through a series of rooms, all related to " \
        "light. Let's see if this contestant can get past the first obstacle!\n" \
        "*The room is mostly empty, except for a locked door to the north side.*"
    R2ld = "One of our contestants is ready to FOCUS on the next puzzle.\n" \
        "*The room is lit by a skylight in the middle of the room, and contains a magnifying lens and mirror.\n" \
           "The east wall feels paper-thin.*"
    R3ld = "Welcome to room 3, hopefully you remember 5th grade science!\n" \
           "*The room has what seems to be a puzzle to the north, along with 2 doors.\n" \
           "The door to the east is open and the one to the south has some kind of lock.*"
    R4ld = "Maybe this contestant can find a hint in this room somewhere - or maybe the exit.\n" \
           "*The room has a locked door to the north labelled 'exit', and a note in a corner.*"
    R5ld = "Looks like our contestant has progressed to the last room, they better hurry up solving that puzzle!\n" \
           "*The room has a another puzzle to the east.*"
    R6ld = "Congratulations contestant! You have escaped and won the 100,000 dollar jackpot!"

    # Now that you have the  long descriptions done you have to create your map
    # Let's start with the 'Inner' Dictionary:
    # {"LocDesc" : R1ld,        - This is the long description to use
    #   "e" : "R2",                     - if they indicate "e"ast this tells you that the next room is R2
    #   "w" : "No",                     - They cannot go West
    #   "n" : "No",                     - They cannot go North
    #   "s" : "No",                     - They cannot go South
    #   "puzzle" : "No",            - The name of the puzzle or No
    #   "lock" : "No",                  - The name of the lock or No
    #   "rsound : "No",                 - The name of the sound file or No
    #   "count" : 0  }                          - The  number of times the player entered this room.

    # using your floor plan create your map - Below is an example

    myMap = {"R1": {"LocDesc": R1ld, "e": "No", "w": "No", "n": "R2", "s": "No", "puzzle": "No", "lock": "ShowTitle",
                    "rsound": "No", "count": 0},
             "R2": {"LocDesc": R2ld, "e": "R3", "w": "No", "n": "No", "s": "R1", "puzzle": "FakeWall", "lock": "No",
                    "rsound": "No", "count": 0, "i": "MirrorGlass"},
             "R3": {"LocDesc": R3ld, "e": "R4", "w": "R2", "n": "No", "s": "R5", "puzzle": "Sunrise", "lock": "LightWaves",
                    "rsound": "No", "count": 0},
             "R4": {"LocDesc": R4ld, "e": "No", "w": "R3", "n": "R6", "s": "No", "puzzle": "SunDone", "lock": "None",
                    "rsound": "No", "count": 0, "i": "LightNote"},
             "R5": {"LocDesc": R5ld, "e": "No", "w": "No", "n": "R3", "s": "No", "puzzle": "Sunset", "lock": "No",
                    "rsound": "No", "count": 0, "i": "Sunset"},
             "R6": {"LocDesc": R6ld, "e": "No", "w": "No", "n": "No", "s": "R4", "puzzle": "No", "lock": "No",
                    "rsound": "No", "count": 0}}

    return myMap


def slow_type(t, speed):
    TypeSound = "./sounds" + "/" + "typing.wav"
    winsound.PlaySound(TypeSound, winsound.SND_ALIAS | winsound.SND_ASYNC )
    for l in t:
        stdout.write(l)
        stdout.flush()
        time.sleep(random.random()*10.0/speed)
    winsound.PlaySound(None, winsound.SND_ALIAS)
    print(' ')


def checkDirection(direction, currLoc):
    LowerD = direction.casefold()
    newSpot = currLoc.get(LowerD)
    # print(newSpot)
    if newSpot != "No":
        return newSpot
    else:
        return None


def handleLock(direction, room):
    currentLock = False
    answering = True
    # checks if the room the player is on matches a lock in the Locks dictionary
    for key in Locks:
        if key == room["lock"]:
            currentLock = key

    try:
        # checks if lock is blocking the direction the player is going
        if direction == Locks[currentLock]["direction"]:
            # checks if lock isn't open yet
            if not Locks[currentLock]["open"]:
                while answering:
                    # asks player question, if right it "opens" the door
                    playerresponse = input(f"{Locks[currentLock]['response']} (type 'back' to exit lock): ").lower()
                    print("")
                    if playerresponse == "back":
                        return "back"
                    elif playerresponse in Locks[currentLock]["solution"]:
                        Locks[currentLock]["open"] = True
                        handleSound(currentLock)
                        slow_type(Locks[currentLock]["solved"], 200)
                        print("")
                        return "continue"
                    elif playerresponse == "q":
                        return "end"
            else:
                return "continue"
    except KeyError:
        return False
    return False


def handleExtra(extra):
    extras = {"LightNote": "The note reads, 'Light is not so different from the tides of the sea you see, for they both"
                           " travel in a way that looks rather hilly",
              "MirrorGlass": "You pick up the magnifying glass for later. The mirror seems like it could be moved",
              "Sunset": "I think I need to solve the puzzle in the previous room."}
    if extra in extras:
        slow_type(extras[extra], 200)
        if extra == "MirrorGlass":
            Puzzles["FakeWall"]["prereq"] = True


def handlePuzzle(room, direction):
    asking = True
    asking2 = True
    for key in Puzzles:
        if key == room["puzzle"]:
            currentPuzzle = key
    try:
        if not Puzzles[currentPuzzle]["solved"]:
            if Puzzles[currentPuzzle]["direction"] == direction:
                if not Puzzles[currentPuzzle]["prereq"]:
                    print("Maybe I should investigate the room")
                    return "back"
                if Puzzles[currentPuzzle]["prereq"]:
                    while asking:
                        slow_type(Puzzles[currentPuzzle]['intro'], 200)
                        answer = input()
                        if answer.lower() in Puzzles[currentPuzzle]["solution"]:
                            slow_type(Puzzles[currentPuzzle]["final"], 300)
                            puzzlecont = currentPuzzle + "2"
                            asking = False
                            # runs the second part of the puzzle, if applicable
                            if puzzlecont in Puzzlescont:
                                while asking2:
                                    slow_type(Puzzlescont[puzzlecont]['intro'], 200)
                                    answer = input()
                                    if answer.lower() in Puzzlescont[puzzlecont]["solution"]:
                                        Puzzles[currentPuzzle]["solved"] = True
                                        slow_type(Puzzlescont[puzzlecont]["final"], 300)
                                        print("")
                                        return False
                            try:
                                handleSound(currentPuzzle)
                                try:
                                    if currentPuzzle == "Sunrise":
                                        Puzzles["Sunset"]["prereq"] = True
                                except:
                                    pass
                            except:
                                pass
                            else:
                                Puzzles[currentPuzzle]["solved"] = True
                                return False
    except UnboundLocalError:
        return False
    return False


def handleSound(solved):
    sounds = {"ShowTitle": "Sounds/lock1.wav",
              "LightWaves": "Sounds/lock2.wav",
              "Burning": "Sounds/puzzle1.wav",
              "Sunrise": "Sounds/puzzle21.wav",
              "Sunset": "Sounds/puzzle22.wav",
              "Escape": "Sounds/applause.wav"}
    # plays sound related to event that happened
    if solved in sounds:
        winsound.PlaySound(sounds[solved], winsound.SND_ALIAS)


# resources
Locks = {"ShowTitle": {"room": "R1",
                        "direction": "n",
                           "response": "The lock asks, 'what game show are you currently on?'",
                           "solution": ["effortless escape"],
                           "solved": "Looks like our contestant managed to remember the name of the show, but it only"
                                     " gets harder from here!",
                           "open": False},
             "LightWaves": {"room": "R3",
                            "direction": "s",
                            "response": "The lock asks, 'how does light travel?'",
                            "solution": ["waves", "in waves"],
                            "solved": "Good job contestant, it seems you payed more attention in class than some of "
                                      "your competitors.",
                            "open": False}}
Puzzles = {"FakeWall": {"intro": "Maybe reflecting light onto this wall will help.\n"
                                 "Where do you want to place the mirror in the room?",
                            "solution": ["middle", "in the middle", "in middle"],
                            "room": "R2",
                            "direction": "e",
                            "prereq": False,
                            "solved": False,
                            "final": "The mirror is reflecting light onto the thin wall"},
           "Sunrise": {"intro": "The puzzle consists of a table with an arrow on it, and a painting of a sunrise on the "
                                "wall behind it. \n A note beside it reads, 'When the sun rises from the east I face it to "
                                "admire the beauty, but when it sets I look the other way to prepare for the next day.'\n"
                                "Which direction do you want to face the arrow?  ",
                            "solution": ["east", "face east", "eastward", "to the east", "the east", "e"],
                            "room": "R2",
                            "direction": "n",
                            "prereq": True,
                            "solved": False,
                            "final": "Good job contestant, now find the other half of the puzzle!"},
           "Sunset": {"intro": "The puzzle consists of a table with an arrow on it, and a painting of a sunset on the "
                                "wall behind it. \n The note I recall read, 'When the sun rises from the east I face it to "
                                "admire the beauty, but when it sets on west I look the other way to prepare for the next day.'\n"
                                "Which direction do you want to face the arrow?  ",
                            "solution": ["east", "face east", "eastward", "to the east", "the east", "e"],
                            "room": "R2",
                            "direction": "e",
                            "prereq": False,
                            "solved": False,
                            "final": "Looks like a contestant has opened the exit! It's a race to the finish!"}}
Puzzlescont = {"FakeWall2": {"intro": "Maybe if I focus the light it will be able to burn through the wall.\n"
                                      "What item could I use with the mirror to burn the wall?",
                             "solution": ["magnifier", "magnifying glass", "magnify"],
                             "final": "*The magnified light burnt through the wall, somehow not engulfing anything else.* \n"
                                      "Wow contestant, try not to burn down our set!"}}

maplist = loadMap()
startLoc = "R1"
prePlayerLoc = startLoc
playerLoc = startLoc
keepPlaying = True

while keepPlaying:
    currLoc = maplist.get(playerLoc)
    lockName = currLoc.get("lock")
    puzzleName = currLoc.get("puzzle")
    currLoc["count"] += 1
    slow_type("Lock : {lockName} and Puzzle : {puzzleName}", 300)
    slow_type(currLoc.get("LocDesc"), 300)
    if playerLoc == "R6":
        handleSound("Escape")
        keepPlaying = False
    if playerLoc == "R6":
        pass
    else:
        prompt = "\n" + "Contestant" + ", What would you like to do? : "
        playerAction = input(prompt)
        if playerAction == "i":
            try:
                handleExtra(currLoc["i"])
                print("")
            except KeyError:
                print("Nothing to investigate here")

        elif playerAction.lower() == "q":
            keepPlaying = False

        elif playerAction.lower() == "n" and playerLoc == "R4":
            if Puzzles["Sunrise"]["solved"] and Puzzles["Sunset"]["solved"]:
                playerLoc = "R6"
            else:
                slow_type("Not so fast contestant, you need to solve the puzzles first", 200)
                playerLoc = "R4"

        else:
            locksit = handleLock(playerAction, currLoc)
            if locksit == "back":
                pass
            elif locksit == "continue" or not locksit:
                puzzlesit = handlePuzzle(currLoc, playerAction)

                if puzzlesit == "back":
                    pass
                elif puzzlesit == "continue" or not puzzlesit:
                    prevPlayerLoc = currLoc

                    if playerAction.lower() == "n" or playerAction.lower() == "s" or playerAction.lower() == "w" \
                            or playerAction.lower() == "e":
                        newLoc = checkDirection(playerAction.lower(), currLoc)

                        if newLoc:
                            playerLoc = newLoc
                        else:
                            try:
                                if Puzzles[currLoc.get("puzzle")]["direction"] == playerAction:
                                    print("")
                            except ValueError:
                                print("You cannot go that way")
                    else:
                        print("That is not a direction")
            elif locksit == "end":
                keepPlaying = False
