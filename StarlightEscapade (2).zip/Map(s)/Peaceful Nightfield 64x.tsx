<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Peaceful Nightfield 64x" tilewidth="64" tileheight="64" tilecount="207" columns="23">
 <image source="download.png" width="1472" height="576"/>
 <tile id="30">
  <animation>
   <frame tileid="28" duration="600"/>
   <frame tileid="29" duration="600"/>
   <frame tileid="30" duration="600"/>
   <frame tileid="29" duration="600"/>
  </animation>
 </tile>
 <tile id="31">
  <animation>
   <frame tileid="28" duration="400"/>
   <frame tileid="29" duration="400"/>
   <frame tileid="30" duration="400"/>
   <frame tileid="29" duration="400"/>
  </animation>
 </tile>
</tileset>
