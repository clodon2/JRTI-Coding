<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Cavernas" tilewidth="8" tileheight="8" tilecount="96" columns="8">
 <image source="C:/Users/Student/Downloads/cavesofgallet/cavesofgallet_tiles.png" width="64" height="96"/>
</tileset>
