# Corey Verkouteren
# 4/1/2022 -
# Importing Tiled Maps

import os
import arcade as arc

SCREEN_WIDTH = 1100
SCREEN_HEIGHT = 650
SCREEN_TITLE = "Starlight Escapade"

TILE_SCALING = .75
CHARACTER_SCALING = TILE_SCALING * 2
SPRITE_PIXEL_SIZE = 64
GRID_PIXEL_SIZE = SPRITE_PIXEL_SIZE * TILE_SCALING

LEFT_VIEWPORT_MARGIN = 200
RIGHT_VIEWPORT_MARGIN = 200
BOTTOM_VIEWPORT_MARGIN = 150
TOP_VIEWPORT_MARGIN = 100

PLAYER_MOVEMENT_SPEED = 3
GRAVITY = 1.5
PLAYER_JUMP_SPEED = 30
DEAD_ZONE = 0.05
PLAYER_START_X = 1
PLAYER_START_Y = 30

RIGHT_FACING = 1
LEFT_FACING = 0

LAYER_NAME_PLATFORMS = "Platforms"
LAYER_NAME_TERRAIN = "Terrain"
LAYER_NAME_FOLIAGE = "Foliage"
LAYER_NAME_ADDBACKGROUND = "Add. Background"
LAYER_NAME_CAVEBACKGROUND = "Cave Background"
LAYER_NAME_BACKGROUND = "Background"

LAYER_NAME_PLAYER = "Player"


class MyGame(arc.Window):
    """
    Main application class.
    """
    def __init__(self):
        """
        Initializer for the game
        """
        # Call the parent class and set up the window
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
        self.left_pressed = False
        self.right_pressed = False
        self.jump_needs_reset = False
        self.up_pressed = False
        self.down_pressed = False
        # Set the path to start with this program
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)
        # Our TileMap Object
        self.tile_map = None
        # Our Scene Object
        self.scene = None
        # Separate variable that holds the player sprite
        self.player_sprite = None
        # Our 'physics' engine
        self.physics_engine = None
        # A Camera that can be used for scrolling the screen
        self.camera = None
        # A Camera that can be used to draw GUI elements
        self.gui_camera = None
        self.end_of_map = 0

    def setup(self):
        """Set up the game here. Call this function to restart the game."""
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/map164x.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

    def on_draw(self):
        """Render the screen."""
        # Clear the screen to the background color
        self.clear()
        arc.set_background_color(arc.color.LIGHT_BROWN)
        # Activate the game camera
        self.camera.use()
        # Draw our Scene
        self.scene.draw()
        # Activate the GUI camera before drawing GUI elements
        self.gui_camera.use()
        # Draw hit boxes.
        # for wall in self.wall_list:
        #   wall.draw_hit_box(arc.color.BLACK, 3)
        #
        # self.player_sprite.draw_hit_box(arc.color.RED, 3)


def main():
        """Main function"""
        window = MyGame()
        window.setup()
        arc.run()


if __name__ == "__main__":
        main()
