import sqlite3 as sq
from sqlite3 import Error


# connects to database
def dbConnection():
    conn = None
    try:
        conn = sq.connect("GameStats.db")
    except Error as e:
        print(e)

    return conn


def getAllPlayers():
    players = []
    conn = dbConnection()
    cursor = conn.execute("SELECT UserID FROM Stats")
    for row in cursor:
        row = row[0]
        players.append(row)
    conn.close()
    return players


# inserts player as a new row for database if they aren't in it already
def insertPlayer(user):
    if user not in getAllPlayers():
        conn = dbConnection()
        curr = conn.cursor()
        # separate values to avoid "injection" attacks, unnecessary here but a good habit
        insert = f"INSERT INTO Stats VALUES (?, ?)"
        curr.execute(insert, (user, 0))
        conn.commit()
        conn.close()
    else:
        pass


# updates the user's stats
def saveGameStats(user, highscore):
    conn = dbConnection()
    curr = conn.cursor()
    updateSQL = f"UPDATE Stats set Highscore = ? WHERE UserID = ?"
    record = (highscore, user)
    curr.execute(updateSQL, record)
    conn.commit()
    conn.close()


# grabs top ten players by score
def getLeaderboard():
    conn = dbConnection()
    top7 = []
    cursor = conn.execute("SELECT * FROM Stats ORDER BY Highscore DESC")
    for row in cursor:
        top7.append(row)
    conn.close()
    print(top7)
    return top7[:7]


# returns highscore of the user
def getStats(user):
    conn = dbConnection()
    cursor = conn.execute(f"SELECT Highscore FROM Stats WHERE UserID = ?", [user])
    for row in cursor:
        # fixes bug in closing from menu where database checks for a user that doesn't exist, thus there is no result
        if row[0] is None:
            return 0
        else:
            return row[0]
    conn.close()


def clearStats():
    conn = dbConnection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Stats")
    conn.commit()
    conn.close()
