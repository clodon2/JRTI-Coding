# Corey Verkouteren
# 4/1/2022 -
# Making A Platforming Game

# Notes: Gems currently not in actual tiled map, waiting until tiled animations are fixed.
# Gem Icon GUI is probably set up wrong as I sorta guessed how to do it
# Gems/Gem Icon GUI have no collection animation
# Grass animation (and all tiled animations) are currently broken for me
# taking damage while facing the opposite direction of where the attacker is and attacking makes you take no knockback

import os
from os import walk
import arcade as arc
import Levels

SCREEN_WIDTH = 1100
SCREEN_HEIGHT = 650
SCREEN_TITLE = "Starlight Escapade"

TILE_SCALING = .65
CHARACTER_SCALING = 1
SPRITE_PIXEL_SIZE = 64
GRID_PIXEL_SIZE = SPRITE_PIXEL_SIZE * TILE_SCALING

MAP_HEIGHT = GRID_PIXEL_SIZE * 20
MAP_WIDTH = GRID_PIXEL_SIZE * 80

LEFT_VIEWPORT_MARGIN = 200
RIGHT_VIEWPORT_MARGIN = 200
BOTTOM_VIEWPORT_MARGIN = 150
TOP_VIEWPORT_MARGIN = 100

PLAYER_MOVEMENT_SPEED = 5
GRAVITY = 1
PLAYER_JUMP_SPEED = 20
DEAD_ZONE = 0.05
PLAYER_START_X = 1
PLAYER_START_Y = 30

RIGHT_FACING = 0
LEFT_FACING = 1

LAYER_NAME_NEXTLEVEL = "Next Level"
LAYER_NAME_ENEMY = "Enemy"
LAYER_NAME_ENEMYTURN = "Enemy Turnaround"
LAYER_NAME_COLLECTABLE = "Collectables"
LAYER_NAME_PLATFORMS = "Platforms"
LAYER_NAME_TERRAIN = "Terrain"
LAYER_NAME_FOLIAGE = "Foliage"
LAYER_NAME_ANIMATED = "Animated"
LAYER_NAME_ADDBACKGROUND = "Add. Background"
LAYER_NAME_CAVEBACKGROUND = "Cave Background"
LAYER_NAME_BACKGROUND = "Background"

LAYER_NAME_PLAYER = "Player"


def load_frame(filename):
    """
    Load a texture pair, with the second being a mirror image.
    """
    return [
            arc.load_texture(filename),
            arc.load_texture(filename, flipped_horizontally=True),
    ]


def load_animation(path):
    frames = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_texture = load_frame(full_path)
            frames.append(image_texture)
    return frames


def check_side(player, entity):
    if player > entity:
        return "Left"
    elif player < entity:
        return "Right"
    else:
        return "Right"


def check_facing(face):
    if face == 0:
        return "Right"
    elif face == 1:
        return "Left"
    else:
        return "None"


class Entity(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.facing = RIGHT_FACING

        self.cur_texture = 0
        self.scale = CHARACTER_SCALING


class Player(Entity):
    def __init__(self):
        # Set up parent class
        super().__init__()
        # If adding the other animations, make sure to scale them up
        self.walk_frames = load_animation("./Sprites/Rogue/Run")
        self.idle_frames = load_animation("./Sprites/Rogue/Idle")
        self.jump_frames = load_animation("./Sprites/Rogue/Jump")
        self.fall_frames = load_animation("./Sprites/Rogue/Fall")
        self.death_frames = load_animation("./Sprites/Rogue/Death")
        self.pullsword_frames = load_animation("./Sprites/Rogue/Pull Sword")
        self.stashsword_frames = load_animation("./Sprites/Rogue/Stash Sword")
        self.sideslash_frames = load_animation("./Sprites/Rogue/Side Slash")
        self.spell_frames = load_animation("./Sprites/Rogue/Spell")
        self.dash_frames = load_animation("./Sprites/Rogue/Dash2")
        self.sideslash = False
        self.spell = False
        self.dashing = False
        self.attacking = False
        self.attackframes = False
        self.knockback = False
        self.health = 100
        self.mana = 0
        self.texture = self.idle_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)

    def side_slash(self):
        self.sideslash = True
        self.attacking = True

    def heal(self):
        self.spell = True
        self.attacking = True

    def dash(self):
        self.dashing = True
        self.attacking = True

    def reset_animation(self):
        self.cur_texture = 0

    def reset(self):
        self.health = 1
        self.scale = 1
        self.hit_box = self.idle_frames[0][0].hit_box_points
        self.center_x = PLAYER_START_X
        self.center_y = PLAYER_START_Y

    def update_animation(self, delta_time: float = 1/15):
        # Figure out if we need to flip face left or right
        if self.change_x < 0 and self.facing == RIGHT_FACING:
            self.facing = LEFT_FACING
        elif self.change_x > 0 and self.facing == LEFT_FACING:
            self.facing = RIGHT_FACING

        if not self.health <= 0:
            if not self.attacking:
                # Walking animation
                if self.change_x != 0 and self.change_y == 0:
                    self.cur_texture += .21
                    if round(self.cur_texture) > len(self.walk_frames) - 1:
                        self.cur_texture = 0
                    self.texture = self.walk_frames[round(self.cur_texture)][self.facing]
                # Jumping/Falling animation
                if self.change_y != 0:
                    if self.change_y < 0:
                        self.cur_texture += .1
                        if round(self.cur_texture) > len(self.fall_frames) - 1:
                            self.cur_texture = 0
                        self.texture = self.fall_frames[round(self.cur_texture)][self.facing]
                    elif self.change_y > 0:
                        self.cur_texture += .5
                        if self.cur_texture > len(self.jump_frames) - 2:
                            if self.change_x != 0:
                                self.cur_texture = len(self.jump_frames) - 1
                            else:
                                self.cur_texture = len(self.jump_frames) - 2
                        self.texture = self.jump_frames[round(self.cur_texture)][self.facing]
                # Idle animation
                if self.change_x == 0 and self.change_y == 0:
                    self.cur_texture += .05
                    if round(self.cur_texture) > len(self.idle_frames) - 1:
                        self.cur_texture = 0
                    self.texture = self.idle_frames[round(self.cur_texture)][self.facing]

            # Attacks
            if self.sideslash:
                self.cur_texture += .3
                if self.cur_texture > len(self.pullsword_frames) - 1:
                    if self.cur_texture - 3 > len(self.sideslash_frames) - 1:
                        self.attackframes = False
                        if round(self.cur_texture) - 7 > len(self.stashsword_frames) - 1:
                            self.sideslash = False
                            self.attacking = False
                        else:
                            self.texture = self.stashsword_frames[round(self.cur_texture) - 7][self.facing]
                    else:
                        if self.cur_texture - 3 >= 0:
                            # activates sword hitbox
                            self.attackframes = True
                        self.texture = self.sideslash_frames[round(self.cur_texture) - 3][self.facing]
                else:
                    self.texture = self.pullsword_frames[round(self.cur_texture)][self.facing]
            if self.spell:
                self.cur_texture += .1
                if self.cur_texture > len(self.spell_frames) - 1:
                    self.attacking = False
                    self.spell = False
                else:
                    self.attackframes = False
                    if self.cur_texture == 7.19999999999999:
                        self.attackframes = True
                    self.texture = self.spell_frames[round(self.cur_texture)][self.facing]
            if self.dashing:
                self.cur_texture += .2
                if self.cur_texture > len(self.dash_frames) - 1:
                    self.attacking = False
                    self.dashing = False
                    self.attackframes = False
                    self.change_x = 0
                else:
                    self.attackframes = True
                    self.texture = self.dash_frames[round(self.cur_texture)][self.facing]

        # death
        if self.health <= 0:
            self.change_x = 0
            self.change_y = 0
            self.scale = 1.6
            self.hit_box = self.death_frames[0][0].hit_box_points
            self.cur_texture += .16
            if round(self.cur_texture) > len(self.death_frames) - 1:
                self.reset()
            else:
                self.texture = self.death_frames[round(self.cur_texture)][self.facing]



class SwordHitbox(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.cur_texture = 0
        self.btextures = load_frame("Sprites/Sword Hitbox.png")
        self.texture = self.btextures[0]
        self.set_hit_box(self.texture.hit_box_points)

    def update_animation(self, delta_time: float = 1 / 15):
        pass


class Gem(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.cur_texture = 0
        self.spin_frames = load_animation("./Sprites/Gem")
        self.texture = self.spin_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)

    def update_animation(self, delta_time: float = 1 / 15):
        self.cur_texture += .05
        if round(self.cur_texture) > len(self.spin_frames) - 1:
            self.cur_texture = 0
        self.texture = self.spin_frames[round(self.cur_texture)][0]


class GemIcon(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.collected = False
        self.textures = [arc.texture.load_texture("Sprites/Gem_Icon/tile0.png"),
                         arc.texture.load_texture("Sprites/Gem_Icon/tile1.png")]
        self.texture = self.textures[0]

    def GemGrabbed(self):
        self.texture = self.textures[1]
        self.collected = True

    def GemLost(self):
        self.collected = False
        self.texture = self.textures[0]


class DarkHound(Entity):
    def __init__(self):
        # Set up parent class
        super().__init__()
        self.scale = 1
        self.walk_frames = load_animation("./Sprites/Hell Hound/Walk")
        self.death_frames = load_animation("./Sprites/Hell Hound/Death")
        self.change_x = 1
        self.texture = self.walk_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)
        self.dead = False

    def die(self):
        self.dead = True
        self.cur_texture = 0

    def update_animation(self, delta_time: float = 1 / 15):
        # Figure out if we need to flip face left or right
        # inversed because initial frames are facing left
        if self.change_x > 0 and self.facing == RIGHT_FACING:
            self.facing = LEFT_FACING
        elif self.change_x < 0 and self.facing == LEFT_FACING:
            self.facing = RIGHT_FACING

        # death animation
        if self.dead:
            self.scale = 3
            self.change_x = 0
            self.change_y = 0
            self.cur_texture += 1
            # fully kills enemy once animation is over
            if round(self.cur_texture) > len(self.death_frames) - 1:
                self.remove_from_sprite_lists()
                self.dead = False
                self.cur_texture = self.cur_texture - 1
            self.texture = self.death_frames[round(self.cur_texture)][self.facing]

        # walking animation
        if self.change_x != 0 and self.change_y == 0:
            self.cur_texture += .2
            if round(self.cur_texture) > len(self.walk_frames) - 1:
                self.cur_texture = 0
            self.texture = self.walk_frames[round(self.cur_texture)][self.facing]


class HealthBar(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.textures = [arc.texture.load_texture("Sprites/Healthbar/HealthBar.png"),
                         arc.texture.load_texture("Sprites/Healthbar/HealthBar Fill.png")]
        self.texture = self.textures[0]
        self.filltexture = self.textures[1]
        self.filltexturehp = 224
        self.filltextureh = 0
        self.filltexturecenterx = 0
        self.filltexturecentery = 0

    def update_health(self, damage, health):
        # updates healthbar to represent current player hp
        # gets percents based on player hp (100)
        damagepercent = damage/100
        healthpercent = health/100
        finalpercent = damagepercent + healthpercent
        # prevents healthbar glitching out when negative health is present
        if finalpercent <= 0:
            # underfill
            self.filltexturehp = 0
        # prevents overfill
        elif finalpercent >= 1:
            self.filltexturehp = self.filltexture.width
            self.filltexturecenterx = 196 - (224 - self.filltexturehp)/2
        # updates healthbar size and keeps it inside the bar
        else:
            self.filltexturehp = self.filltexture.width*finalpercent
            self.filltexturecenterx = 196 - (224 - self.filltexturehp)/2


class Manabar(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.textures = [arc.texture.load_texture("Sprites/Manabar/ManaCharge2.png"),
                         arc.texture.load_texture("Sprites/Manabar/ManaCharge Fill.png"),
                         arc.texture.load_texture("Sprites/Manabar/ManaCharge Fill2.png")]
        self.texture = self.textures[0]
        self.filltexture = self.textures[1]
        self.filltexture2 = self.textures[2]
        self.filltexture.center_x = 0
        self.filltexture.center_y = 0
        self.filltexture2.center_x = 0
        self.filltexture2.center_y = 0
        self.charges = 0

    def update_mana(self, mana):
        # updates manabar to represent current player mana
        self.charges = mana


class MyGame(arc.Window):
    """
    Main application class.
    """
    def __init__(self):
        """
        Initializer for the game
        """
        # Call the parent class and set up the window
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
        self.LEVEL = 0
        self.LEVELS = [self.setup, self.setup2]
        self.left_pressed = False
        self.right_pressed = False
        self.jump_needs_reset = False
        self.up_pressed = False
        self.down_pressed = False
        self.d_pressed = False
        self.s_pressed = False
        self.f_pressed = False
        # Set the path to start with this program
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)
        # Our TileMap Object
        self.tile_map = None
        # Our Scene Object
        self.scene = None
        # Separate variable that holds the player sprite
        self.player_sprite = None
        # Our 'physics' engine
        self.physics_engine = None
        # A Camera that can be used for scrolling the screen
        self.camera = None
        # A Camera that can be used to draw GUI elements
        self.gui_camera = None
        self.end_of_map = 0
        self.gem_sprite = None
        self.gem_list = None

        self.kbdirection = None
        # Sounds
        # http://freesoundeffect.net/sound/gem-collect-sparkle-sound-effect
        self.gem_collect = arc.load_sound("./Sounds/Gem Collect.mp3")
        self.sword_slash1 = arc.load_sound("./Sounds/sword1.wav")
        self.hound_death = arc.load_sound("./Sounds/enemydeath.mp3")

    def setup(self):
        """Set up the game here. Call this function to restart the game."""
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/map164x.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_NEXTLEVEL: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_ENEMY: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_ENEMYTURN: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_COLLECTABLE: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": True
        },
        LAYER_NAME_ANIMATED: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

        # Set up the player, specifically placing it at these coordinates.
        self.player_sprite = Player()
        self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * PLAYER_START_X)
        self.player_sprite.center_y = (self.tile_map.tile_height * TILE_SCALING * PLAYER_START_Y)
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.player_sprite)

        # Sword Hitbox Setup
        self.hitter = SwordHitbox()
        self.hitter.center_x = self.player_sprite.center_x + 37
        self.hitter.center_y = self.player_sprite.center_y + 13
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.hitter)
        self.hitter.alpha = 0

        # Set up Gems
        self.gem_sprite = Gem()
        self.gem_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 31)
        self.gem_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 5)
        self.gem_list = arc.SpriteList()
        self.gem_list.append(self.gem_sprite)
        self.scene.add_sprite(LAYER_NAME_COLLECTABLE, self.gem_sprite)

        # Set up gem icon
        self.gemicon_sprite = GemIcon()
        self.gemicon_sprite.center_x = 30
        self.gemicon_sprite.center_y = 620

        # Set up Healthbar
        self.healthbar_sprite = HealthBar()
        self.healthbar_sprite.center_x = 160
        self.healthbar_sprite.center_y = 45
        self.healthbar_sprite.filltexturecenterx = self.healthbar_sprite.center_x + 36
        self.healthbar_sprite.filltexturecentery = self.healthbar_sprite.center_y - 2

        # Set up Manabar
        self.manabar_sprite = Manabar()
        self.manabar_sprite.center_x = 135
        self.manabar_sprite.center_y = 80
        self.manabar_sprite.filltexture.center_x = self.manabar_sprite.center_x - 31
        self.manabar_sprite.filltexture.center_y = self.manabar_sprite.center_y + 2
        self.manabar_sprite.filltexture2.center_x = self.manabar_sprite.center_x + 31
        self.manabar_sprite.filltexture2.center_y = self.manabar_sprite.center_y + 2

        # Set up enemies
        self.enemy1_sprite = DarkHound()
        self.enemy1_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 28)
        self.enemy1_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 9.9)
        self.enemy_list = arc.SpriteList()
        self.enemy_list.append(self.enemy1_sprite)
        self.scene.add_sprite(LAYER_NAME_ENEMY, self.enemy1_sprite)

        # Play sounds so game doesnt lag when played (idk why this happens)
        self.gem_collect.play(0)
        self.hound_death.play(0)

        # timer type thing
        self.timer = 0

        # knockback
        self.kbdirection = 0

        # text
        arc.load_font("Other/Bitty.ttf")
        self.movement_text = arc.Text("Use arrow keys to move", start_x=(4 * GRID_PIXEL_SIZE), start_y=(12 * GRID_PIXEL_SIZE),
                                      color=arc.color.WHITE, font_size=50, font_name="Bitty")
        self.attack_text = arc.Text("Press D to ATTACK!", start_x=(24*GRID_PIXEL_SIZE), start_y=(14*GRID_PIXEL_SIZE),
                                    color=arc.color.WHITE, font_size=50, font_name="Bitty")
        self.mana_text = arc.Text("Killing enemies gives you MANA"
                                  ", MANA can be used to DASH by pressing F, "
                                  "or to HEAL by pressing S", start_x=(40*GRID_PIXEL_SIZE), start_y=(16*GRID_PIXEL_SIZE),
                                  color=arc.color.WHITE, font_size=50, font_name="Bitty", multiline=True, width=(10*GRID_PIXEL_SIZE))

        self.text_list = []
        self.text_list.append(self.movement_text)
        self.text_list.append(self.attack_text)
        self.text_list.append(self.mana_text)

        # arrow
        self.arrow = arc.texture.load_texture("Sprites/Arrow.png")

        # Create the 'physics engine'
        self.physics_engine = arc.PhysicsEnginePlatformer(
                self.player_sprite,
                gravity_constant=GRAVITY,
                walls=(self.scene[LAYER_NAME_TERRAIN], self.scene[LAYER_NAME_PLATFORMS])
        )

    def setup2(self):
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/Map2.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_ENEMY: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_ENEMYTURN: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_COLLECTABLE: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": True
        },
        LAYER_NAME_ANIMATED: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

        # Set up the player, specifically placing it at these coordinates.
        self.player_sprite = Player()
        self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * PLAYER_START_X)
        self.player_sprite.center_y = (self.tile_map.tile_height * TILE_SCALING * PLAYER_START_Y)
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.player_sprite)

        # Sword Hitbox Setup
        self.hitter = SwordHitbox()
        self.hitter.center_x = self.player_sprite.center_x + 37
        self.hitter.center_y = self.player_sprite.center_y + 13
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.hitter)
        self.hitter.alpha = 0

        # Set up Gems, add to scene
        self.gem_list = arc.SpriteList()

        # Set up gem icon
        self.gemicon_sprite = GemIcon()
        self.gemicon_sprite.center_x = 30
        self.gemicon_sprite.center_y = 620

        # Set up Healthbar
        self.healthbar_sprite = HealthBar()
        self.healthbar_sprite.center_x = 160
        self.healthbar_sprite.center_y = 45
        self.healthbar_sprite.filltexturecenterx = self.healthbar_sprite.center_x + 36
        self.healthbar_sprite.filltexturecentery = self.healthbar_sprite.center_y - 2

        # Set up Manabar
        self.manabar_sprite = Manabar()
        self.manabar_sprite.center_x = 135
        self.manabar_sprite.center_y = 80
        self.manabar_sprite.filltexture.center_x = self.manabar_sprite.center_x - 31
        self.manabar_sprite.filltexture.center_y = self.manabar_sprite.center_y + 2
        self.manabar_sprite.filltexture2.center_x = self.manabar_sprite.center_x + 31
        self.manabar_sprite.filltexture2.center_y = self.manabar_sprite.center_y + 2

        # Set up enemies, add to scene
        self.enemy_list = arc.SpriteList()

        # Play sounds so game doesnt lag when played (idk why this happens)
        self.gem_collect.play(0)
        self.hound_death.play(0)

        # timer type thing
        self.timer = 0

        # knockback
        self.kbdirection = 0

        # Create the 'physics engine'
        self.physics_engine = arc.PhysicsEnginePlatformer(
                self.player_sprite,
                gravity_constant=GRAVITY,
                walls=(self.scene[LAYER_NAME_TERRAIN], self.scene[LAYER_NAME_PLATFORMS])
        )


    def on_draw(self):
        """Render the screen."""
        # Clear the screen to the background color
        self.clear()
        arc.set_background_color((24, 12, 52))
        # Activate the game camera
        self.camera.use()
        # Draw our Scene
        self.scene.draw()
        for t in self.text_list:
            t.draw()
        self.arrow.draw_scaled(center_x=(70*GRID_PIXEL_SIZE), center_y=(10*GRID_PIXEL_SIZE), scale=1)
        # Activate the GUI camera before drawing GUI elements
        self.gui_camera.use()

        # Gem GUI
        self.gemicon_sprite.draw()
        # Healthbar
        self.healthbar_sprite.draw()
        self.healthbar_sprite.filltexture.draw_sized(self.healthbar_sprite.filltexturecenterx,
                                                     self.healthbar_sprite.filltexturecentery,
                                                     width=self.healthbar_sprite.filltexturehp,
                                                     height=self.healthbar_sprite.filltexture.height)
        self.manabar_sprite.draw()
        if self.player_sprite.mana > 0:
            if self.manabar_sprite.charges == 1:
                self.manabar_sprite.filltexture.draw_scaled(self.manabar_sprite.filltexture.center_x, self.manabar_sprite.filltexture.center_y, 1)
            if self.manabar_sprite.charges == 2:
                self.manabar_sprite.filltexture.draw_scaled(self.manabar_sprite.filltexture.center_x, self.manabar_sprite.filltexture.center_y, 1)
                self.manabar_sprite.filltexture2.draw_scaled(self.manabar_sprite.filltexture2.center_x, self.manabar_sprite.filltexture2.center_y, 1)
        # Draw hit boxes.
        # self.enemy1_sprite.draw_hit_box(arc.color.ORANGE, 3)
        #
        # self.player_sprite.draw_hit_box(arc.color.RED, 3)
        # if self.player_sprite.attackframes:
            # self.hitter.draw_hit_box(arc.color.ANDROID_GREEN, 3)

    def process_keychange(self):
        # Process left/right
        if self.right_pressed and not self.left_pressed:
            self.player_sprite.change_x = PLAYER_MOVEMENT_SPEED
        elif self.left_pressed and not self.right_pressed:
            self.player_sprite.change_x = -PLAYER_MOVEMENT_SPEED
        else:
            self.player_sprite.change_x = 0
        if self.up_pressed and not self.down_pressed:
            if self.physics_engine.can_jump(y_distance=10) and not self.jump_needs_reset:
                self.player_sprite.change_y = PLAYER_JUMP_SPEED
                self.jump_needs_reset = True
        # side slash attack if d is pressed
        if self.down_pressed:
            self.respawn_enemy()
        if self.d_pressed:
            if not self.player_sprite.attacking:
                self.sword_slash1.play(.7)
                self.player_sprite.side_slash()
        if self.s_pressed:
            if self.player_sprite.mana > 0:
                if not self.player_sprite.attacking:
                    self.player_sprite.heal()
                    self.change_mana(-1)
        if self.f_pressed:
            if self.player_sprite.mana > 0:
                if not self.player_sprite.attacking:
                    self.player_sprite.dash()
                    self.change_mana(-1)
        if self.player_sprite.dashing:
            self.player_sprite.change_y = 0
        elif self.player_sprite.attacking:
            self.player_sprite.change_x = 0
            self.player_sprite.change_y = 0

    def on_key_press(self, key, modifiers):
        if not self.player_sprite.health == 0:
            if key == arc.key.LEFT:
                self.left_pressed = True
            if key == arc.key.RIGHT:
                self.right_pressed = True
            if key == arc.key.UP:
                self.up_pressed = True
            if key == arc.key.DOWN:
                self.down_pressed = True
            if key == arc.key.S:
                if not self.player_sprite.attacking:
                    self.player_sprite.cur_texture = 0
                    self.s_pressed = True
            if key == arc.key.F:
                if not self.player_sprite.attacking:
                    self.player_sprite.cur_texture = 0
                    self.f_pressed = True
            if key == arc.key.D:
                if not self.player_sprite.attacking:
                    self.player_sprite.cur_texture = 0
                    self.d_pressed = True
            if key != arc.key.D or key != arc.key.S or key != arc.key.F:
                if not self.player_sprite.attacking:
                    self.player_sprite.cur_texture = 0
            self.process_keychange()

    def on_key_release(self, key, modifiers):
        if not self.player_sprite.health == 0:
            if key == arc.key.LEFT:
                self.left_pressed = False
            if key == arc.key.RIGHT:
                self.right_pressed = False
            if key == arc.key.UP:
                self.up_pressed = False
            if key == arc.key.DOWN:
                self.down_pressed = False
            if arc.key.S:
                self.s_pressed = False
            if arc.key.F:
                self.f_pressed = False
            if key == arc.key.D:
                self.player_sprite
                self.d_pressed = False
            if key != arc.key.D or key != arc.key.S or key != arc.key.F:
                if not self.player_sprite.attacking:
                    self.player_sprite.cur_texture = 0
            self.process_keychange()

    def center_camera_to_player(self, speed=0.2):
        screen_center_x = self.player_sprite.center_x - (self.camera.viewport_width / 2)
        screen_center_y = self.player_sprite.center_y - (self.camera.viewport_height / 2)
        if screen_center_x < 0:
            screen_center_x = 0
        if screen_center_y < 0:
            screen_center_y = 0

        # keeps camera in map
        if screen_center_x + self.camera.viewport_width > MAP_WIDTH:
            screen_center_x = MAP_WIDTH - self.camera.viewport_width
        if screen_center_y + self.camera.viewport_height > MAP_HEIGHT:
            screen_center_y = MAP_HEIGHT - self.camera.viewport_height

        player_centered = screen_center_x, screen_center_y

        self.camera.move_to(player_centered, speed)

    def reset_game(self):
        self.LEVELS[self.LEVEL]()

    def next_level(self):
        self.LEVEL += 1
        self.LEVELS[self.LEVEL]()
        # clears draw lists so level enemies don't overlap
        self.text_list.clear()
        self.enemy_list.clear()
        self.gem_list.clear()

    def respawn_enemy(self):
        if self.enemy1_sprite not in self.enemy_list:
            self.enemy1_sprite = DarkHound()
            self.enemy1_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 28)
            self.enemy1_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 9.9)
            self.enemy_list = arc.SpriteList()
            self.enemy_list.append(self.enemy1_sprite)
            self.scene.add_sprite(LAYER_NAME_ENEMY, self.enemy1_sprite)

    def change_playerhp(self, change):
        self.healthbar_sprite.update_health(change, self.player_sprite.health)
        self.healthbar_sprite.update()
        if not self.player_sprite.health + change > 100:
            self.player_sprite.health += change

    def change_mana(self, mana):
        self.player_sprite.mana += mana
        # prevents overfill and underfill
        if self.player_sprite.mana > 2:
            self.player_sprite.mana = 2
        if self.player_sprite.mana < 0:
            self.player_sprite.mana = 0
        self.manabar_sprite.update_mana(self.player_sprite.mana)
        self.manabar_sprite.update()

    def on_update(self, delta_time):
        self.timer += 1
        if not self.player_sprite.health <= 0:
            self.physics_engine.update()
        if self.physics_engine.can_jump:
            self.jump_needs_reset = False

        # Next Level
        if arc.check_for_collision_with_list(self.player_sprite, self.scene[LAYER_NAME_NEXTLEVEL]):
            self.next_level()

        # Enemy movement
        self.enemy1_sprite.update()
        for e in self.enemy_list:
            if arc.check_for_collision_with_list(e, self.scene[LAYER_NAME_ENEMYTURN]):
                e.change_x *= -1

        # Sword hitbox update
        if self.player_sprite.facing == RIGHT_FACING:
            if not self.hitter.texture == self.hitter.btextures[0]:
                self.hitter.texture = self.hitter.btextures[0]
                self.hitter.hit_box = self.hitter.texture.hit_box_points
            self.hitter.center_x = self.player_sprite.center_x + 37
            self.hitter.center_y = self.player_sprite.center_y + 13
        elif self.player_sprite.facing == LEFT_FACING:
            if not self.hitter.texture == self.hitter.btextures[1]:
                self.hitter.texture = self.hitter.btextures[1]
                self.hitter.hit_box = self.hitter.texture.hit_box_points
            self.hitter.center_x = self.player_sprite.center_x - 37
            self.hitter.center_y = self.player_sprite.center_y + 13

        # Player abilities (attack, heal, etc.)
        if self.player_sprite.attacking:
            if self.player_sprite.attackframes:
                # Player Sword-Enemy collision
                if self.player_sprite.side_slash:
                    for i in arc.check_for_collision_with_list(self.hitter, self.enemy_list):
                        if check_side(self.player_sprite.center_x, i.center_x) == check_facing(self.player_sprite.facing):
                            # disables killing the entity multiple times while hitboxes intersect
                            if not i.dead:
                                self.hound_death.play(1.2)
                                i.die()
                                self.change_mana(1)
                        # kills player if facing wrong direction
                        else:
                            self.change_playerhp(-30)
                            if self.player_sprite.health == 0:
                                self.player_sprite.reset_animation()
                            else:
                                self.player_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 10)
                                self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 1)
                if self.player_sprite.spell:
                    self.change_playerhp(30)
                if self.player_sprite.dashing:
                    if check_facing(self.player_sprite.facing) == "Right":
                        self.player_sprite.change_x = 30
                    elif check_facing(self.player_sprite.facing) == "Left":
                        self.player_sprite.change_x = -30

        if self.player_sprite.dashing:
            self.player_sprite.change_y = 0

        # Player-Enemy collision
        if not self.player_sprite.attacking and not self.player_sprite.health == 0:
            for i in arc.check_for_collision_with_list(self.player_sprite, self.enemy_list):
                if not i.dead:
                    self.change_playerhp(-30)
                    if self.player_sprite.health == 0:
                        self.player_sprite.reset_animation()
                    else:
                        self.player_sprite.knockback = 5 + self.timer
                        # determines knockback direction
                        self.kbdirection = self.player_sprite.center_x - i.center_x

        # Player Knockback
        if self.player_sprite.knockback:
            # stops knockback effect when timer for it is up
            if self.player_sprite.knockback <= self.timer:
                self.player_sprite.knockback = False
                self.player_sprite.change_x = 0
                self.player_sprite.change_y = 0
            # if hit from left, knocks player to the right
            elif self.kbdirection >= 0:
                self.player_sprite.change_x = 10
                self.player_sprite.change_y = 10
            # if hit from right, knocks player to the left
            elif self.kbdirection <= 0:
                self.player_sprite.change_x = -10
                self.player_sprite.change_y = 10

        # Player-Gem Collision
        for i in arc.check_for_collision_with_list(self.player_sprite, self.gem_list):
            # play collect sound, drops frames sometimes and idk why
            arc.play_sound(self.gem_collect)
            # updates gem collection GUI
            self.gemicon_sprite.GemGrabbed()
            i.remove_from_sprite_lists()

        # resets to start if fall off map
        if self.player_sprite.center_y + 500 < 0:
            self.reset_game()

        # Position the camera
        self.center_camera_to_player()
        self.scene.update_animation(delta_time, [LAYER_NAME_PLAYER, LAYER_NAME_ANIMATED, LAYER_NAME_COLLECTABLE, LAYER_NAME_ENEMY])


def main():
    """Main function"""
    window = MyGame()
    window.setup()
    arc.run()


if __name__ == "__main__":
    main()
