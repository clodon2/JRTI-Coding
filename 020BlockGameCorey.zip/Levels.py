# Corey Verkouteren
# Levels for BlockGameCorey
# Corey Verkouteren
# 2/11/22 -
# Testing out features
import time

import pygame as pg
import pygame.freetype
import random as rd
from pygame.locals import *
from os import walk
import Menus

pg.init()
pg.font.init()

# Notes: Collision system somewhat unorthodox, created myself, and thus went through many renditions which left
# the floor as it's own collision, if reused it will be fixed


class Player(pg.sprite.Sprite):
    jumpvelocity = -8.2
    gravity = 1
    airtime = 0
    collcount = 0
    xmovement = 0
    ymovement = 0
    lives = 4
    jump = False
    collided = False
    dead = False

    def __init__(self, spriteimage):
        super(Player, self).__init__()
        self.animationpace = 0
        self.framecount = 0
        self.damage3 = import_folder("Images/BlockCharacter/3 Damage")
        self.damage2 = import_folder("Images/BlockCharacter/2 Damage")
        self.damage1 = import_folder("Images/BlockCharacter/1 Damage")
        self.damage0 = import_folder("Images/BlockCharacter/No Damage")
        self.surf = pg.image.load(spriteimage)
        self.rect = self.surf.get_rect(center=(
            (SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
        ))

    def loselife(self):
        self.lives -= 1

    def setcollision(self, yn):
        self.collided = yn

    # obstacle collisions, inspired by Mr.Ball's version
    def collisioncheck(self, collrect):
        if pg.Rect.colliderect(self.rect, collrect):
            # bottom side collision
            if (self.rect.bottom - self.ymovement) <= collrect.top:
                player.rect.bottom = collrect.top
                self.jump = False
                self.ymovement = 0
                self.collcount = 0
            # right side collision
            elif self.rect.right >= collrect.left > player.rect.left and self.rect.bottom > collrect.top:
                player.rect.right = collrect.left
            # left side collision
            elif self.rect.left <= collrect.right < player.rect.right and self.rect.bottom > collrect.top:
                player.rect.left = collrect.right

    def reset(self):
        self.xmovement = 0
        self.ymovement = 0
        self.collcount = 0
        self.jump = False
        self.collided = False
        self.dead = False
        self.lives = 4
        self.airtime = 0
        self.rect = self.surf.get_rect(center=(SCREEN_WIDTH/2, 0))

    def update(self, keypress):
        self.ymovement = 0
        self.xmovement = 0
        # floor collision
        if self.collided:
            self.jump = False
            self.ymovement = 0
            self.collcount = 0
        elif not self.collided:
            if self.collcount < 1:
                # for gravity calculations, need time been in air
                self.airtime = pg.time.get_ticks()
            # adds gravity if player not on ground
            self.ymovement += self.gravity*((pg.time.get_ticks() - self.airtime)/60)
            self.collcount += 1

        # jump
        if keypress[K_w]:
            self.jump = True
        if self.jump:
            self.ymovement += self.jumpvelocity

        # horizontal movement
        if keypress[K_d]:
            self.xmovement += 3
        if keypress[K_a]:
            self.xmovement -= 3

        # final movement
        self.rect.move_ip(self.xmovement, self.ymovement)

        # keeps player on screen
        if self.rect.right <= 0:
            player.dead = True
        if self.rect.left >= SCREEN_WIDTH:
            player.dead = True
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

        if self.lives == 0:
            player.dead = True

        # animation
        if self.lives == 4:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.damage0) - 1:
                    self.framecount = 0
                self.surf = self.damage0[self.framecount]
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200
        if self.lives == 3:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.damage1) - 1:
                    self.framecount = 0
                self.surf = self.damage1[self.framecount]
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200
        if self.lives == 2:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.damage2) - 1:
                    self.framecount = 0
                self.surf = self.damage2[self.framecount]
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200
        if self.lives == 1:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.damage3) - 1:
                    self.framecount = 0
                self.surf = self.damage3[self.framecount]
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200


class Obstacle(pg.sprite.Sprite):
    def __init__(self, size, location, mtype):
        super(Obstacle, self).__init__()
        self.type = mtype
        self.xmovement = -5
        self.surf = pg.surface.Surface(size)
        if mtype == "kill":
            self.surf.fill(red)
        else:
            self.surf.fill(white)
        self.rect = self.surf.get_rect(center=location)

    def movementpath(self):
        if self.type == "floor":
            pass
        if self.type == "left" or self.type == "kill":
            if self.rect.right <= 0:
                obstacle_rects.remove(self.rect)
                self.kill()
        if self.type == "bounce":
            if self.rect.left <= 0:
                self.xmovement *= -1
            if self.rect.right >= SCREEN_WIDTH:
                self.xmovement *= -1

    def update(self):
        self.rect.move_ip(self.xmovement, 0)


def resetGame():
    player.reset()
    for entity in obstacle_sprites:
        entity.kill()
    obstacle_rects.clear()
    print(obstacle_rects)


# from JrtiGameSupport
def import_folder(path):
    surface_list = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_surf = pg.image.load(full_path).convert_alpha()
            surface_list.append(image_surf)

    return surface_list


SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
running = True

clock = pg.time.Clock()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("Block Jumper")
white = (255, 255, 255)
red = (200, 0, 0)
black = (0, 0, 0)
blue = (0, 0, 200)

player = Player("Images/blockcharacter2.png")

obstacle_rects = []
obstacle_sprites = pg.sprite.Group()


def MainGame():
    floor = Obstacle((800, 100), (SCREEN_WIDTH / 2, 600), "floor")

    ADDOBSTACLE = pg.USEREVENT + 1
    ADDKILLOBSTACLE = pg.USEREVENT + 2
    pg.time.set_timer(ADDOBSTACLE, 1500)
    pg.time.set_timer(ADDKILLOBSTACLE, 2200)

    obstacleoptions = [(100, 50), (100, 50), (50, 50), (50, 70), (50, 100)]
    killobstacleoptions = [(50, 50), (50, 75)]

    for entity in obstacle_sprites:
        obstacle_rects.append(entity.rect)

    while running:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                return False

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return False

            if event.type == ADDOBSTACLE:
                newobstacle = Obstacle(rd.choice(obstacleoptions), (SCREEN_WIDTH, 500), "left")
                obstacle_sprites.add(newobstacle)
                obstacle_rects.append(newobstacle.rect)

            if event.type == ADDKILLOBSTACLE:
                killobstacle = Obstacle(rd.choice(killobstacleoptions), (SCREEN_WIDTH, 500), "kill")
                obstacle_sprites.add(killobstacle)
                obstacle_rects.append(killobstacle.rect)

        if player.dead:
            return "Game Over"

        # Updates

        pressed_keys = pg.key.get_pressed()
        player.update(pressed_keys)

        pg.draw.rect(screen, blue, screen.get_rect())

        for entity in obstacle_sprites:
            entity.movementpath()
            entity.update()
            if entity.type == "kill":
                if pg.Rect.colliderect(entity.rect, player.rect):
                    player.loselife()
                    entity.kill()
            player.collisioncheck(entity.rect)

        # floor collision
        if pg.Rect.colliderect(player.rect, floor):
            player.rect.bottom = floor.rect.top
            player.setcollision(True)
        else:
            player.setcollision(False)


        for entity in obstacle_sprites:
            screen.blit(entity.surf, entity.rect)

        screen.blit(floor.surf, floor.rect)

        screen.blit(player.surf, player.rect)
        pg.display.flip()
        clock.tick(60)
