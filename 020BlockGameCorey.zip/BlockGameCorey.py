# Corey Verkouteren
# 2/11/22 -
# Testing out features

import pygame as pg
import pygame.freetype
from pygame.locals import *
import Menus
import Levels

# Block Jumper

running = True
inmenu = True
intutorial = False
inmaingame = False
gameover = False

while running:
    while inmenu:
        menuresult = Menus.MainMenu()
        if menuresult == "Tutorial":
            intutorial = True
            inmenu = False
        elif menuresult == "Start Game":
            inmaingame = True
            inmenu = False
        elif not menuresult:
            running = False
            inmenu = False
    while inmaingame:
        gameresult = Levels.MainGame()
        if gameresult == "Game Over":
            gameover = True
            inmaingame = False
        elif not gameresult:
            running = False
            inmaingame = False
    while gameover:
        menuresult = Menus.GameOver()
        if menuresult == "Retry":
            Levels.resetGame()
            inmaingame = True
            gameover = False
        elif menuresult == "Main Menu":
            Levels.resetGame()
            inmenu = True
            gameover = False
        elif not menuresult:
            running = False
            gameover = False
