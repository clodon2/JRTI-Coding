<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Peaceful Nightfield" tilewidth="8" tileheight="8" tilecount="207" columns="23">
 <image source="C:/Users/Student/Downloads/peaceful_nightfield/tileset.png" width="184" height="72"/>
 <tile id="31">
  <animation>
   <frame tileid="28" duration="400"/>
   <frame tileid="29" duration="400"/>
   <frame tileid="30" duration="400"/>
   <frame tileid="29" duration="400"/>
  </animation>
 </tile>
</tileset>
