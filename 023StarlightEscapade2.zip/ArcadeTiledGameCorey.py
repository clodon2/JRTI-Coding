# Corey Verkouteren
# 4/1/2022 -
# Making A Platforming Game

# Notes: Gems currently not in actual tiled map, waiting until tiled animations are fixed.
# Gem Icon GUI is probably set up wrong as I sorta guessed how to do it
# Gems/Gem Icon GUI have no collection animation
# Player sprite is low quality due to scaling, have to fix at some point
# Platforms currently act as normal terrain
# Grass animation (and all tiled animations) are currently broken for me
# Gem collect sound tends to drop frames for unknown reason
# Player jump animation only works correctly if key is held down
# attack system is inefficient
# current "DarkHound" enemy will likely be replaced due to lack of death animation

import os
from os import walk
import arcade as arc

SCREEN_WIDTH = 1100
SCREEN_HEIGHT = 650
SCREEN_TITLE = "Starlight Escapade"

TILE_SCALING = .65
CHARACTER_SCALING = 1
SPRITE_PIXEL_SIZE = 64
GRID_PIXEL_SIZE = SPRITE_PIXEL_SIZE * TILE_SCALING

LEFT_VIEWPORT_MARGIN = 200
RIGHT_VIEWPORT_MARGIN = 200
BOTTOM_VIEWPORT_MARGIN = 150
TOP_VIEWPORT_MARGIN = 100

PLAYER_MOVEMENT_SPEED = 5
GRAVITY = 1
PLAYER_JUMP_SPEED = 20
DEAD_ZONE = 0.05
PLAYER_START_X = 1
PLAYER_START_Y = 30

RIGHT_FACING = 0
LEFT_FACING = 1

LAYER_NAME_ENEMY = "Enemy"
LAYER_NAME_ENEMYTURN = "Enemy Turnaround"
LAYER_NAME_COLLECTABLE = "Collectables"
LAYER_NAME_PLATFORMS = "Platforms"
LAYER_NAME_TERRAIN = "Terrain"
LAYER_NAME_FOLIAGE = "Foliage"
LAYER_NAME_ANIMATED = "Animated"
LAYER_NAME_ADDBACKGROUND = "Add. Background"
LAYER_NAME_CAVEBACKGROUND = "Cave Background"
LAYER_NAME_BACKGROUND = "Background"

LAYER_NAME_PLAYER = "Player"


def load_frame(filename):
    """
    Load a texture pair, with the second being a mirror image.
    """
    return [
            arc.load_texture(filename),
            arc.load_texture(filename, flipped_horizontally=True),
    ]


def load_animation(path):
    frames = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_texture = load_frame(full_path)
            frames.append(image_texture)
    return frames


def check_side(player, entity):
    if player > entity:
        return "Left"
    elif player < entity:
        return "Right"
    else:
        return "Right"


def check_facing(face):
    if face == 0:
        return "Right"
    elif face == 1:
        return "Left"
    else:
        return "None"


class Entity(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.facing = RIGHT_FACING

        self.cur_texture = 0
        self.scale = CHARACTER_SCALING


class Player(Entity):
    def __init__(self):
        # Set up parent class
        super().__init__()
        # If adding the other animations, make sure to scale them up
        self.walk_frames = load_animation("./Sprites/Rogue/Run")
        self.idle_frames = load_animation("./Sprites/Rogue/Idle")
        self.jump_frames = load_animation("./Sprites/Rogue/Jump")
        self.fall_frames = load_animation("./Sprites/Rogue/Fall")
        self.pullsword_frames = load_animation("./Sprites/Rogue/Pull Sword")
        self.stashsword_frames = load_animation("./Sprites/Rogue/Stash Sword")
        self.sideslash_frames = load_animation("./Sprites/Rogue/Side Slash")
        self.sideslash = False
        self.attacking = False
        self.texture = self.idle_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)

    def side_slash(self):
        self.sideslash = True
        self.attacking = True

    def update_animation(self, delta_time: float = 1/15):
        # Figure out if we need to flip face left or right
        if self.change_x < 0 and self.facing == RIGHT_FACING:
            self.facing = LEFT_FACING
        elif self.change_x > 0 and self.facing == LEFT_FACING:
            self.facing = RIGHT_FACING

        if not self.attacking:
            # Walking animation
            if self.change_x != 0 and self.change_y == 0:
                self.cur_texture += .2
                if round(self.cur_texture) > len(self.walk_frames) - 1:
                    self.cur_texture = 0
                self.texture = self.walk_frames[round(self.cur_texture)][self.facing]
            # Jumping/Falling animation
            if self.change_y != 0:
                if self.change_y < 0:
                    self.cur_texture += .1
                    if round(self.cur_texture) > len(self.fall_frames) - 1:
                        self.cur_texture = 0
                    self.texture = self.fall_frames[round(self.cur_texture)][self.facing]
                elif self.change_y > 0:
                    self.cur_texture += .5
                    if self.cur_texture > len(self.jump_frames) - 2:
                        if self.change_x != 0:
                            self.cur_texture = len(self.jump_frames) - 1
                        else:
                            self.cur_texture = len(self.jump_frames) - 2
                    self.texture = self.jump_frames[round(self.cur_texture)][self.facing]
            # Idle animation
            if self.change_x == 0 and self.change_y == 0:
                self.cur_texture += .05
                if round(self.cur_texture) > len(self.idle_frames) - 1:
                    self.cur_texture = 0
                self.texture = self.idle_frames[round(self.cur_texture)][self.facing]

        # Attacks
        if self.sideslash:
            self.cur_texture += .3
            if self.cur_texture > len(self.pullsword_frames) - 1:
                if self.cur_texture - 3 > len(self.sideslash_frames) - 1:
                    if round(self.cur_texture) - 7 > len(self.stashsword_frames) - 1:
                        self.hit_box = self.texture.hit_box_points
                        self.sideslash = False
                        self.attacking = False
                    else:
                        self.texture = self.stashsword_frames[round(self.cur_texture) - 7][self.facing]
                else:
                    self.texture = self.sideslash_frames[round(self.cur_texture) - 3][self.facing]
                    self.hit_box = self.texture.hit_box_points
            else:
                self.texture = self.pullsword_frames[round(self.cur_texture)][self.facing]


class Gem(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.cur_texture = 0
        self.spin_frames = load_animation("./Sprites/Gem")
        self.texture = self.spin_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)

    def update_animation(self, delta_time: float = 1 / 15):
        self.cur_texture += .05
        if round(self.cur_texture) > len(self.spin_frames) - 1:
            self.cur_texture = 0
        self.texture = self.spin_frames[round(self.cur_texture)][0]


class GemIcon(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.scale = 1
        self.collected = False
        self.textures = [arc.texture.load_texture("Sprites/Gem_Icon/tile0.png"),
                         arc.texture.load_texture("Sprites/Gem_Icon/tile1.png")]
        self.texture = self.textures[0]

    def GemGrabbed(self):
        self.texture = self.textures[1]


class DarkHound(Entity):
    def __init__(self):
        # Set up parent class
        super().__init__()
        self.scale = 1
        self.walk_frames = load_animation("./Sprites/Hell Hound/Walk")
        self.death_frames = load_animation("./Sprites/Hell Hound/Death")
        self.change_x = 1
        self.texture = self.walk_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)
        self.dead = False

    def die(self):
        self.dead = True
        self.cur_texture = 0

    def update_animation(self, delta_time: float = 1 / 15):
        # Figure out if we need to flip face left or right
        # inversed because initial frames are facing left
        if self.change_x > 0 and self.facing == RIGHT_FACING:
            self.facing = LEFT_FACING
        elif self.change_x < 0 and self.facing == LEFT_FACING:
            self.facing = RIGHT_FACING

        # death animation
        if self.dead:
            self.scale = 3
            self.change_x = 0
            self.change_y = 0
            self.cur_texture += 1
            # fully kills enemy once animation is over
            if round(self.cur_texture) > len(self.death_frames) - 1:
                self.remove_from_sprite_lists()
                self.dead = False
                self.cur_texture = self.cur_texture - 1
            self.texture = self.death_frames[round(self.cur_texture)][self.facing]

        # walking animation
        if self.change_x != 0 and self.change_y == 0:
            self.cur_texture += .2
            if round(self.cur_texture) > len(self.walk_frames) - 1:
                self.cur_texture = 0
            self.texture = self.walk_frames[round(self.cur_texture)][self.facing]


class MyGame(arc.Window):
    """
    Main application class.
    """
    def __init__(self):
        """
        Initializer for the game
        """
        # Call the parent class and set up the window
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
        self.left_pressed = False
        self.right_pressed = False
        self.jump_needs_reset = False
        self.up_pressed = False
        self.down_pressed = False
        self.d_pressed = False
        # Set the path to start with this program
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)
        # Our TileMap Object
        self.tile_map = None
        # Our Scene Object
        self.scene = None
        # Separate variable that holds the player sprite
        self.player_sprite = None
        # Our 'physics' engine
        self.physics_engine = None
        # A Camera that can be used for scrolling the screen
        self.camera = None
        # A Camera that can be used to draw GUI elements
        self.gui_camera = None
        self.end_of_map = 0
        self.gem_sprite = None
        self.gem_list = None
        # Sounds
        # http://freesoundeffect.net/sound/gem-collect-sparkle-sound-effect
        self.gem_collect = arc.load_sound("./Sounds/Gem Collect.mp3")
        self.sword_slash1 = arc.load_sound("./Sounds/sword1.wav")
        self.hound_death = arc.load_sound("./Sounds/enemydeath.mp3")

    def setup(self):
        """Set up the game here. Call this function to restart the game."""
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/map164x.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_ENEMY: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_ENEMYTURN: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_COLLECTABLE: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": True
        },
        LAYER_NAME_ANIMATED: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

        # Set up the player, specifically placing it at these coordinates.
        self.player_sprite = Player()
        self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * PLAYER_START_X)
        self.player_sprite.center_y = (self.tile_map.tile_height * TILE_SCALING * PLAYER_START_Y)
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.player_sprite)

        # Set up Gems
        self.gem_sprite = Gem()
        self.gem_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 31)
        self.gem_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 5)
        self.gem_list = arc.SpriteList()
        self.gem_list.append(self.gem_sprite)
        self.scene.add_sprite(LAYER_NAME_COLLECTABLE, self.gem_sprite)

        # Set up gem icon
        self.gemicon_sprite = GemIcon()
        self.gemicon_sprite.center_x = 30
        self.gemicon_sprite.center_y = 620

        # Set up enemies
        self.enemy1_sprite = DarkHound()
        self.enemy1_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 28)
        self.enemy1_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 9.9)
        self.enemy_list = arc.SpriteList()
        self.enemy_list.append(self.enemy1_sprite)
        self.scene.add_sprite(LAYER_NAME_ENEMY, self.enemy1_sprite)

        # Play sounds so game doesnt lag when played (idk why this happens)
        self.gem_collect.play(0)
        self.hound_death.play(0)

        # Create the 'physics engine'
        self.physics_engine = arc.PhysicsEnginePlatformer(
                self.player_sprite,
                gravity_constant=GRAVITY,
                walls=(self.scene[LAYER_NAME_TERRAIN], self.scene[LAYER_NAME_PLATFORMS])
        )

    def on_draw(self):
        """Render the screen."""
        # Clear the screen to the background color
        self.clear()
        arc.set_background_color((24, 12, 52))
        # Activate the game camera
        self.camera.use()
        # Draw our Scene
        self.scene.draw()
        # Activate the GUI camera before drawing GUI elements
        self.gui_camera.use()

        # Gem GUI
        self.gemicon_sprite.draw()
        # Draw hit boxes.
        # self.enemy1_sprite.draw_hit_box(arc.color.ORANGE, 3)
        #
        # self.player_sprite.draw_hit_box(arc.color.RED, 3)

    def process_keychange(self):
        # Process left/right
        if self.right_pressed and not self.left_pressed:
            self.player_sprite.change_x = PLAYER_MOVEMENT_SPEED
        elif self.left_pressed and not self.right_pressed:
            self.player_sprite.change_x = -PLAYER_MOVEMENT_SPEED
        else:
            self.player_sprite.change_x = 0
        if self.up_pressed and not self.down_pressed:
            if self.physics_engine.can_jump(y_distance=10) and not self.jump_needs_reset:
                self.player_sprite.change_y = PLAYER_JUMP_SPEED
                self.jump_needs_reset = True
        # side slash attack if d is pressed
        if self.d_pressed:
            if not self.player_sprite.attacking:
                self.sword_slash1.play(.7)
                self.player_sprite.side_slash()
        if self.player_sprite.attacking:
            self.player_sprite.change_x = 0
            self.player_sprite.change_y = 0

    def on_key_press(self, key, modifiers):
        if key == arc.key.LEFT:
            self.left_pressed = True
        if key == arc.key.RIGHT:
            self.right_pressed = True
        if key == arc.key.UP:
            self.up_pressed = True
        if key == arc.key.DOWN:
            self.down_pressed = True
        if key == arc.key.D:
            if not self.player_sprite.attacking:
                self.player_sprite.cur_texture = 0
                self.d_pressed = True
        if key != arc.key.D:
            if not self.player_sprite.attacking:
                self.player_sprite.cur_texture = 0
        self.process_keychange()

    def on_key_release(self, key, modifiers):
        if key == arc.key.LEFT:
            self.left_pressed = False
        if key == arc.key.RIGHT:
            self.right_pressed = False
        if key == arc.key.UP:
            self.up_pressed = False
        if key == arc.key.DOWN:
            self.down_pressed = False
        if key == arc.key.D:
            self.player_sprite
            self.d_pressed = False
        if key != arc.key.D:
            if not self.player_sprite.attacking:
                self.player_sprite.cur_texture = 0
        self.process_keychange()

    def center_camera_to_player(self, speed=0.2):
        screen_center_x = self.player_sprite.center_x - (self.camera.viewport_width / 2)
        screen_center_y = self.player_sprite.center_y - (self.camera.viewport_height / 2)
        if screen_center_x < 0:
            screen_center_x = 0
        if screen_center_y < 0:
            screen_center_y = 0
        player_centered = screen_center_x, screen_center_y

        self.camera.move_to(player_centered, speed)

    def on_update(self, delta_time):
        self.physics_engine.update()
        if self.physics_engine.can_jump:
            self.jump_needs_reset = False

        # Enemy movement
        self.enemy1_sprite.update()
        for e in self.enemy_list:
            if arc.check_for_collision_with_list(e, self.scene[LAYER_NAME_ENEMYTURN]):
                e.change_x *= -1

        # Player Sword-Enemy collision
        if self.player_sprite.attacking:
            for i in arc.check_for_collision_with_list(self.player_sprite, self.enemy_list):
                # checks if player is facing enemy
                if check_side(self.player_sprite.center_x, i.center_x) == check_facing(self.player_sprite.facing):
                    # disables killing the entity multiple times while hitboxes intersect
                    if not i.dead:
                        self.hound_death.play(1.2)
                        i.die()
                # kills player if facing wrong direction
                else:
                    self.player_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 10)
                    self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 1)

        # Player-Enemy collision
        if not self.player_sprite.attacking:
            for i in arc.check_for_collision_with_list(self.player_sprite, self.enemy_list):
                if not i.dead:
                    self.player_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 10)
                    self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 1)

        # Player-Gem Collision
        for i in arc.check_for_collision_with_list(self.player_sprite, self.gem_list):
            # play collect sound, drops frames sometimes and idk why
            arc.play_sound(self.gem_collect)
            # updates gem collection GUI
            self.gemicon_sprite.GemGrabbed()
            i.remove_from_sprite_lists()

        # resets to start if fall off map
        if self.player_sprite.center_y + 500 < 0:
            self.player_sprite.center_y = (self.tile_map.tile_width * TILE_SCALING * 10)
            self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * 1)

        # Position the camera
        self.center_camera_to_player()
        self.scene.update_animation(delta_time, [LAYER_NAME_PLAYER, LAYER_NAME_ANIMATED, LAYER_NAME_COLLECTABLE, LAYER_NAME_ENEMY])


def main():
    """Main function"""
    window = MyGame()
    window.setup()
    arc.run()


if __name__ == "__main__":
    main()
