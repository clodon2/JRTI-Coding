# Corey Verkouteren
# 4/1/2022 -
# Making A Platforming Game

import os
from os import walk
import arcade as arc

SCREEN_WIDTH = 1100
SCREEN_HEIGHT = 650
SCREEN_TITLE = "Starlight Escapade"

TILE_SCALING = .75
CHARACTER_SCALING = TILE_SCALING * 4
SPRITE_PIXEL_SIZE = 64
GRID_PIXEL_SIZE = SPRITE_PIXEL_SIZE * TILE_SCALING

LEFT_VIEWPORT_MARGIN = 200
RIGHT_VIEWPORT_MARGIN = 200
BOTTOM_VIEWPORT_MARGIN = 150
TOP_VIEWPORT_MARGIN = 100

PLAYER_MOVEMENT_SPEED = 5
GRAVITY = 1
PLAYER_JUMP_SPEED = 25
DEAD_ZONE = 0.05
PLAYER_START_X = 1
PLAYER_START_Y = 30

RIGHT_FACING = 0
LEFT_FACING = 1

LAYER_NAME_PLATFORMS = "Platforms"
LAYER_NAME_TERRAIN = "Terrain"
LAYER_NAME_FOLIAGE = "Foliage"
LAYER_NAME_ANIMATED = "Animated"
LAYER_NAME_ADDBACKGROUND = "Add. Background"
LAYER_NAME_CAVEBACKGROUND = "Cave Background"
LAYER_NAME_BACKGROUND = "Background"

LAYER_NAME_PLAYER = "Player"


def load_frame(filename):
    """
    Load a texture pair, with the second being a mirror image.
    """
    return [
            arc.load_texture(filename),
            arc.load_texture(filename, flipped_horizontally=True),
    ]


def load_animation(path):
    frames = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_texture = load_frame(full_path)
            frames.append(image_texture)
    return frames


class Entity(arc.Sprite):
    def __init__(self):
        super().__init__()
        self.facing = RIGHT_FACING

        self.cur_texture = 0
        self.scale = CHARACTER_SCALING


class Player(Entity):
    def __init__(self):
        # Set up parent class
        super().__init__()
        self.walk_frames = load_animation("./Sprites/Rogue/Run")
        self.idle_frames = load_animation("./Sprites/Rogue/Idle")
        self.jump_frames = load_animation("./Sprites/Rogue/Jump")
        self.fall_frames = load_animation("./Sprites/Rogue/Fall")
        self.texture = self.idle_frames[0][0]
        self.set_hit_box(self.texture.hit_box_points)

    def update_animation(self, delta_time: float = 1/15):
        # Figure out if we need to flip face left or right
        if self.change_x < 0 and self.facing == RIGHT_FACING:
            self.facing = LEFT_FACING
        elif self.change_x > 0 and self.facing == LEFT_FACING:
            self.facing = RIGHT_FACING
        # Walking animation
        if self.change_x != 0 and self.change_y == 0:
            self.cur_texture += .3
            if round(self.cur_texture) > len(self.walk_frames) - 1:
                self.cur_texture = 0
            self.texture = self.walk_frames[round(self.cur_texture)][self.facing]
        # Jumping/Falling animation
        if self.change_y != 0:
            if self.change_y < 0:
                self.cur_texture += .1
                if round(self.cur_texture) > len(self.fall_frames) - 1:
                    self.cur_texture = 0
                self.texture = self.fall_frames[round(self.cur_texture)][self.facing]
            elif self.change_y > 0:
                self.cur_texture += .5
                if self.cur_texture > len(self.jump_frames) - 2:
                    if self.change_x != 0:
                        self.cur_texture = len(self.jump_frames) - 1
                    else:
                        self.cur_texture = len(self.jump_frames) - 2
                self.texture = self.jump_frames[round(self.cur_texture)][self.facing]
        # Idle animation
        if self.change_x == 0 and self.change_y == 0:
            self.cur_texture += .05
            if round(self.cur_texture) > len(self.idle_frames) - 1:
                self.cur_texture = 0
            self.texture = self.idle_frames[round(self.cur_texture)][self.facing]


class MyGame(arc.Window):
    """
    Main application class.
    """
    def __init__(self):
        """
        Initializer for the game
        """
        # Call the parent class and set up the window
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
        self.left_pressed = False
        self.right_pressed = False
        self.jump_needs_reset = False
        self.up_pressed = False
        self.down_pressed = False
        # Set the path to start with this program
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)
        # Our TileMap Object
        self.tile_map = None
        # Our Scene Object
        self.scene = None
        # Separate variable that holds the player sprite
        self.player_sprite = None
        # Our 'physics' engine
        self.physics_engine = None
        # A Camera that can be used for scrolling the screen
        self.camera = None
        # A Camera that can be used to draw GUI elements
        self.gui_camera = None
        self.end_of_map = 0

    def setup(self):
        """Set up the game here. Call this function to restart the game."""
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/map164x.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": True
        },
        LAYER_NAME_ANIMATED: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

        # Set up the player, specifically placing it at these coordinates.
        self.player_sprite = Player()
        self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * PLAYER_START_X)
        self.player_sprite.center_y = (self.tile_map.tile_height * TILE_SCALING * PLAYER_START_Y)
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.player_sprite)

        # Create the 'physics engine'
        self.physics_engine = arc.PhysicsEnginePlatformer(
                self.player_sprite,
                gravity_constant=GRAVITY,
                walls=(self.scene[LAYER_NAME_TERRAIN])
        )

    def on_draw(self):
        """Render the screen."""
        # Clear the screen to the background color
        self.clear()
        arc.set_background_color(arc.color.LIGHT_BROWN)
        # Activate the game camera
        self.camera.use()
        # Draw our Scene
        self.scene.draw()
        # Activate the GUI camera before drawing GUI elements
        self.gui_camera.use()
        # Draw hit boxes.
        # for wall in self.wall_list:
        #   wall.draw_hit_box(arc.color.BLACK, 3)
        #
        # self.player_sprite.draw_hit_box(arc.color.RED, 3)

    def process_keychange(self):
        # Process left/right
        if self.right_pressed and not self.left_pressed:
            self.player_sprite.change_x = PLAYER_MOVEMENT_SPEED
        elif self.left_pressed and not self.right_pressed:
            self.player_sprite.change_x = -PLAYER_MOVEMENT_SPEED
        else:
            self.player_sprite.change_x = 0
        if self.up_pressed and not self.down_pressed:
            if self.physics_engine.can_jump(y_distance=10) and not self.jump_needs_reset:
                self.player_sprite.change_y = PLAYER_JUMP_SPEED
                self.jump_needs_reset = True

    def on_key_press(self, key, modifiers):
        if key == arc.key.LEFT:
            self.left_pressed = True
        if key == arc.key.RIGHT:
            self.right_pressed = True
        if key == arc.key.UP:
            self.up_pressed = True
        if key == arc.key.DOWN:
            self.down_pressed = True
        self.player_sprite.cur_texture = 0
        self.process_keychange()

    def on_key_release(self, key, modifiers):
        if key == arc.key.LEFT:
            self.left_pressed = False
        if key == arc.key.RIGHT:
            self.right_pressed = False
        if key == arc.key.UP:
            self.up_pressed = False
        if key == arc.key.DOWN:
            self.down_pressed = False
        self.player_sprite.cur_texture = 0
        self.process_keychange()

    def center_camera_to_player(self, speed=0.2):
        screen_center_x = self.player_sprite.center_x - (self.camera.viewport_width / 2)
        screen_center_y = self.player_sprite.center_y - (self.camera.viewport_height / 2)
        if screen_center_x < 0:
            screen_center_x = 0
        if screen_center_y < 0:
            screen_center_y = 0
        player_centered = screen_center_x, screen_center_y

        self.camera.move_to(player_centered, speed)

    def on_update(self, delta_time):
        self.physics_engine.update()
        if self.physics_engine.can_jump:
            self.jump_needs_reset = False
        # Position the camera
        self.center_camera_to_player()
        self.scene.update_animation(delta_time, [LAYER_NAME_PLAYER, LAYER_NAME_ANIMATED])


def main():
        """Main function"""
        window = MyGame()
        window.setup()
        arc.run()


if __name__ == "__main__":
    main()
