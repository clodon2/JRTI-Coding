<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Dark Castle" tilewidth="16" tileheight="16" tilecount="242" columns="22">
 <image source="C:/Users/Student/Downloads/dark_castle_tileset.png" width="358" height="179"/>
 <tile id="116">
  <animation>
   <frame tileid="111" duration="200"/>
   <frame tileid="112" duration="200"/>
   <frame tileid="113" duration="200"/>
   <frame tileid="114" duration="200"/>
  </animation>
 </tile>
</tileset>
